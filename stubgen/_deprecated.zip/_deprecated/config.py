EXTENSION_API_PATH = 'godot-cpp/gdextension/extension_api.json' # Relative to the project root directory



STUB_TYPINGS_PATH = "typings/godot/typings.pyi" # Relative to the project root directory
EXPOSED_STUB_PATH = 'typings/godot/__init__.pyi' # Relative to the project root directory
STUB_ENUM_PATH = 'typings/godot/enums.pyi' # Relative to the project root directory
